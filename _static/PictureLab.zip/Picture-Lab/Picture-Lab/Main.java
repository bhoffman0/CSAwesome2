public class Main 
{
  public static void main(String[] args) 
  {
    Picture pict = new Picture("arch.jpg");
    pict.zeroBlue();
    pict.show();
  }
}
